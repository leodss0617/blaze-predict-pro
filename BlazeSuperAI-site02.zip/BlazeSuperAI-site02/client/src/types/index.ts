export type ColorType = 'red' | 'black' | 'white';

export interface Round {
  id: string;
  number: number;
  color: ColorType;
  timestamp: number;
}

export interface Prediction {
  id: string;
  color: ColorType;
  confidence: number;
  timestamp: number;
  actual?: ColorType;
  correct?: boolean;
}

export type ConfidenceLevel = 'high' | 'medium' | 'low';

export interface AppState {
  rounds: Round[];
  predictions: Prediction[];
  hasVisited: boolean;
  currentPrediction: {
    color: ColorType;
    confidence: number;
    confidenceLevel: ConfidenceLevel;
    message: string;
  } | null;
}
