import { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { getColorFromNumber, getColorDisplayClass, getColorTextClass } from "../lib/utils";

interface InputSectionProps {
  onAddRound: (number: number) => void;
}

const InputSection = ({ onAddRound }: InputSectionProps) => {
  const [roundNumber, setRoundNumber] = useState<string>('');
  
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers 0-14
    if (value === '' || (parseInt(value) >= 0 && parseInt(value) <= 14)) {
      setRoundNumber(value);
    }
  };
  
  const handleAddRound = () => {
    const num = parseInt(roundNumber);
    if (!isNaN(num) && num >= 0 && num <= 14) {
      onAddRound(num);
      setRoundNumber('');
    }
  };
  
  const handleNumberButtonClick = (num: number) => {
    setRoundNumber(num.toString());
  };
  
  const color = getColorFromNumber(parseInt(roundNumber));
  const colorClass = getColorDisplayClass(color);
  const textColorClass = color ? getColorTextClass(color) : '';
  
  return (
    <section className="p-4">
      <div className="bg-surface rounded-xl p-4 shadow-md mb-6">
        <h2 className="text-xl font-montserrat font-bold mb-4">Adicionar Rodada</h2>
        
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1">
            <label htmlFor="roundNumber" className="block text-text-secondary text-sm mb-1">
              Número da Rodada (0-14)
            </label>
            <Input
              id="roundNumber"
              type="number"
              min={0}
              max={14}
              value={roundNumber}
              onChange={handleNumberChange}
              placeholder="Digite um número"
              className="input-number w-full bg-dark border border-gray-700 text-white rounded-lg py-3 px-4 focus:outline-none focus:ring-2 focus:ring-primary text-lg"
            />
          </div>
          <div>
            <label className="block text-text-secondary text-sm mb-1">Cor</label>
            <div 
              className={`h-12 w-12 ${colorClass} rounded-lg flex items-center justify-center text-xl font-bold ${textColorClass}`}
            >
              {roundNumber === '' ? '?' : roundNumber}
            </div>
          </div>
        </div>
        
        {/* Number pad for easier mobile input */}
        <div className="grid grid-cols-5 gap-2 mb-4">
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].map((num) => (
            <Button
              key={num}
              type="button"
              variant="outline"
              className="number-button bg-dark hover:bg-opacity-80 py-3 rounded-lg font-bold"
              onClick={() => handleNumberButtonClick(num)}
            >
              {num}
            </Button>
          ))}
        </div>
        
        <Button 
          className="w-full py-3 bg-secondary text-secondary-foreground rounded-lg font-bold text-lg"
          onClick={handleAddRound}
        >
          Adicionar Rodada
        </Button>
      </div>
    </section>
  );
};

export default InputSection;
