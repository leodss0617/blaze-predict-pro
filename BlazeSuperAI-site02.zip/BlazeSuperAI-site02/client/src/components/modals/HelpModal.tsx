import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../ui/dialog";
import { Button } from "../ui/button";
import { X } from "lucide-react";

interface HelpModalProps {
  open: boolean;
  onClose: () => void;
}

const HelpModal = ({ open, onClose }: HelpModalProps) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-surface border-gray-700 p-6 m-4 max-w-lg rounded-xl">
        <DialogHeader className="flex justify-between items-center">
          <DialogTitle className="text-xl font-bold">Como funciona</DialogTitle>
          <Button variant="ghost" className="h-8 w-8 p-0" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>
        
        <div className="mb-4">
          <h3 className="font-bold mb-2">Regras do jogo</h3>
          <ul className="list-disc pl-5 space-y-1 text-text-secondary">
            <li>Números de 1 a 7 = Vermelho</li>
            <li>Números de 8 a 14 = Preto</li>
            <li>Número 0 = Branco</li>
          </ul>
        </div>
        
        <div className="mb-4">
          <h3 className="font-bold mb-2">Como usar</h3>
          <ol className="list-decimal pl-5 space-y-1 text-text-secondary">
            <li>Digite o número da rodada (0-14)</li>
            <li>Clique em "Adicionar Rodada"</li>
            <li>A IA analisará os padrões e fará uma previsão</li>
            <li>Quanto mais rodadas inserir, mais precisa será a previsão</li>
          </ol>
        </div>
        
        <DialogFooter>
          <Button 
            className="w-full py-3 bg-primary text-white rounded-lg font-bold mt-2"
            onClick={onClose}
          >
            Entendi
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default HelpModal;
