import { Round, Prediction, AppState } from "../types";

const ROUNDS_KEY = 'blazeRounds';
const PREDICTIONS_KEY = 'blazePredictions';
const VISITED_KEY = 'blazeVisited';

export const saveRounds = (rounds: Round[]): void => {
  try {
    localStorage.setItem(ROUNDS_KEY, JSON.stringify(rounds));
  } catch (error) {
    console.error('Error saving rounds to localStorage:', error);
  }
};

export const savePredictions = (predictions: Prediction[]): void => {
  try {
    localStorage.setItem(PREDICTIONS_KEY, JSON.stringify(predictions));
  } catch (error) {
    console.error('Error saving predictions to localStorage:', error);
  }
};

export const saveVisited = (hasVisited: boolean): void => {
  try {
    localStorage.setItem(VISITED_KEY, JSON.stringify(hasVisited));
  } catch (error) {
    console.error('Error saving visited state to localStorage:', error);
  }
};

export const loadRounds = (): Round[] => {
  try {
    const data = localStorage.getItem(ROUNDS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading rounds from localStorage:', error);
    return [];
  }
};

export const loadPredictions = (): Prediction[] => {
  try {
    const data = localStorage.getItem(PREDICTIONS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading predictions from localStorage:', error);
    return [];
  }
};

export const loadVisited = (): boolean => {
  try {
    const data = localStorage.getItem(VISITED_KEY);
    return data ? JSON.parse(data) : false;
  } catch (error) {
    console.error('Error loading visited state from localStorage:', error);
    return false;
  }
};

export const loadAppState = (): AppState => {
  return {
    rounds: loadRounds(),
    predictions: loadPredictions(),
    hasVisited: loadVisited(),
    currentPrediction: null
  };
};

export const saveAppState = (state: AppState): void => {
  saveRounds(state.rounds);
  savePredictions(state.predictions);
  saveVisited(state.hasVisited);
};

export const resetAppState = (): AppState => {
  const newState = {
    rounds: [],
    predictions: [],
    hasVisited: true,
    currentPrediction: null
  };
  saveAppState(newState);
  return newState;
};
