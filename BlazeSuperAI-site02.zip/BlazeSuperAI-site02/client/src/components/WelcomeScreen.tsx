import { Button } from "./ui/button";

interface WelcomeScreenProps {
  onStart: () => void;
}

const WelcomeScreen = ({ onStart }: WelcomeScreenProps) => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-dark py-4 px-4 shadow-md sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-montserrat font-bold">
            Blaze Supreme <span className="text-primary">AI</span>
          </h1>
        </div>
      </header>

      {/* Welcome Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
        <div className="mb-8">
          <h2 className="text-3xl font-montserrat font-bold mb-3">Previsor Inteligente de Cores</h2>
          <p className="text-text-secondary mb-6">
            Análise avançada com IA para prever a próxima cor com base em padrões históricos.
          </p>
        </div>

        {/* Modern dark interface image */}
        <div className="w-full mb-8 rounded-xl overflow-hidden shadow-lg">
          <svg className="w-full h-auto" viewBox="0 0 800 400" xmlns="http://www.w3.org/2000/svg">
            <rect width="800" height="400" fill="#1E1E1E" />
            
            {/* Header mockup */}
            <rect width="800" height="60" fill="#121212" />
            <rect x="20" y="20" width="150" height="20" rx="4" fill="#6200EA" />
            
            {/* Charts and dashboard elements */}
            <rect x="20" y="80" width="370" height="140" rx="8" fill="#262626" />
            <circle cx="120" cy="130" r="50" fill="none" stroke="#F44336" strokeWidth="20" strokeDasharray="251,100" />
            <rect x="210" y="110" width="160" height="12" rx="6" fill="#444" />
            <rect x="210" y="130" width="140" height="12" rx="6" fill="#444" />
            <rect x="210" y="150" width="120" height="12" rx="6" fill="#444" />
            
            {/* Line chart */}
            <rect x="410" y="80" width="370" height="140" rx="8" fill="#262626" />
            <polyline points="430,180 470,150 510,170 550,120 590,140 630,100 670,160 710,90 750,130" 
                    fill="none" stroke="#6200EA" strokeWidth="3" />
            
            {/* Bar chart */}
            <rect x="20" y="240" width="370" height="140" rx="8" fill="#262626" />
            <rect x="50" y="320" width="40" height="40" fill="#F44336" />
            <rect x="110" y="300" width="40" height="60" fill="#212121" />
            <rect x="170" y="280" width="40" height="80" fill="#F44336" />
            <rect x="230" y="260" width="40" height="100" fill="#212121" />
            <rect x="290" y="290" width="40" height="70" fill="#FFFFFF" />
            
            {/* Prediction card */}
            <rect x="410" y="240" width="370" height="140" rx="8" fill="#262626" />
            <rect x="430" y="260" width="80" height="80" rx="8" fill="#F44336" />
            <rect x="530" y="270" width="230" height="16" rx="4" fill="#444" />
            <rect x="530" y="300" width="180" height="16" rx="4" fill="#444" />
            <rect x="430" y="350" width="330" height="16" rx="4" fill="#555" />
          </svg>
        </div>

        {/* Start button */}
        <Button 
          className="w-full py-8 px-6 bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl font-montserrat font-bold text-xl shadow-lg transition-all"
          onClick={onStart}
        >
          COMEÇAR AGORA
        </Button>
      </div>
    </div>
  );
};

export default WelcomeScreen;
