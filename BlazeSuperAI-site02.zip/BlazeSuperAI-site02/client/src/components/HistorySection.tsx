import { useState } from "react";
import { Round, Prediction } from "../types";
import { 
  getColorName, 
  formatTimestamp
} from "../lib/utils";
import { ChevronDown, ChevronUp, Check, X } from "lucide-react";

interface HistorySectionProps {
  rounds: Round[];
  predictions: Prediction[];
}

const HistorySection = ({ rounds, predictions }: HistorySectionProps) => {
  const [expanded, setExpanded] = useState(false);
  
  // If there are no rounds, show a message
  if (rounds.length === 0) {
    return (
      <section className="px-4 mb-20">
        <h2 className="text-xl font-montserrat font-bold mb-3">Histórico</h2>
        <div className="bg-surface rounded-xl p-6 shadow-md text-center">
          <p className="text-text-secondary">
            Adicione rodadas para visualizar o histórico.
          </p>
        </div>
      </section>
    );
  }
  
  // Combine rounds with predictions for display
  const historyItems = rounds.map((round, index) => {
    const prediction = predictions.find(p => p.actual === round.color);
    const confidencePercent = prediction ? Math.round(prediction.confidence * 100) : null;
    
    return {
      round,
      prediction,
      confidencePercent
    };
  });
  
  // Show only the first 3 items if not expanded
  const displayItems = expanded ? historyItems : historyItems.slice(0, 3);
  
  return (
    <section className="px-4 mb-20">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-xl font-montserrat font-bold">Histórico</h2>
        {historyItems.length > 3 && (
          <button 
            className="text-text-secondary flex items-center"
            onClick={() => setExpanded(!expanded)}
          >
            <span className="text-sm">{expanded ? 'Ver menos' : 'Ver tudo'}</span>
            {expanded ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />}
          </button>
        )}
      </div>
      
      <div className="bg-surface rounded-xl overflow-hidden shadow-md">
        {displayItems.map(({ round, prediction, confidencePercent }) => (
          <div key={round.id} className="flex items-center p-3 border-b border-gray-800">
            <div className={`color-indicator color-${round.color} mr-3`}></div>
            <div className="flex-1">
              <div className="flex justify-between">
                <span className="font-medium">Número {round.number}</span>
                {prediction && (
                  <span className={`text-${prediction.correct ? 'green' : 'red'}-500 text-sm flex items-center`}>
                    {prediction.correct ? <Check className="mr-1 h-3 w-3" /> : <X className="mr-1 h-3 w-3" />}
                    {prediction.correct ? 'ACERTO' : 'ERRO'}
                  </span>
                )}
              </div>
              <div className="text-sm text-text-secondary">
                {prediction ? (
                  <>Previsão: {getColorName(prediction.color)} ({confidencePercent}%)</>
                ) : (
                  <span className="italic">Primeira rodada</span>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {!expanded && historyItems.length > 3 && (
          <div className="p-3 text-center">
            <button 
              className="text-primary text-sm font-medium"
              onClick={() => setExpanded(true)}
            >
              Ver mais {historyItems.length - 3} rodadas
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default HistorySection;
