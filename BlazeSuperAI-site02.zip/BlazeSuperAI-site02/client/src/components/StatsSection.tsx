import { Round, Prediction } from "../types";
import { calculateAccuracyTrend } from "../lib/utils";
import ColorDistributionChart from "./charts/ColorDistributionChart";
import AccuracyChart from "./charts/AccuracyChart";
import HitsVsMissesChart from "./charts/HitsVsMissesChart";

interface StatsSectionProps {
  rounds: Round[];
  predictions: Prediction[];
}

const StatsSection = ({ rounds, predictions }: StatsSectionProps) => {
  // Calculate accuracy
  const resolvedPredictions = predictions.filter(p => p.correct !== undefined);
  const correctPredictions = resolvedPredictions.filter(p => p.correct === true);
  
  const accuracy = resolvedPredictions.length > 0 
    ? Math.round((correctPredictions.length / resolvedPredictions.length) * 100) 
    : 0;
  
  // Calculate trend
  const trend = calculateAccuracyTrend(predictions);
  
  return (
    <section className="px-4 mb-6">
      <h2 className="text-xl font-montserrat font-bold mb-3">Estatísticas</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-surface rounded-xl p-4 shadow-md">
          <h3 className="text-sm font-medium text-text-secondary mb-2">Acertos da IA</h3>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold">{accuracy}%</span>
            <span className={`text-${trend > 0 ? 'green' : trend < 0 ? 'red' : 'gray'}-500 text-sm font-medium`}>
              {trend > 0 ? `↑ ${trend}%` : trend < 0 ? `↓ ${Math.abs(trend)}%` : `― 0%`}
            </span>
          </div>
        </div>
        
        <div className="bg-surface rounded-xl p-4 shadow-md">
          <h3 className="text-sm font-medium text-text-secondary mb-2">Rodadas</h3>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold">{rounds.length}</span>
            <span className="text-text-secondary text-sm font-medium">total</span>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 mb-4">
        <div className="bg-surface rounded-xl p-4 shadow-md">
          <h3 className="text-sm font-medium text-text-secondary mb-2">Distribuição de Cores</h3>
          <div className="h-56">
            <ColorDistributionChart rounds={rounds} />
          </div>
        </div>
        
        <div className="bg-surface rounded-xl p-4 shadow-md">
          <h3 className="text-sm font-medium text-text-secondary mb-2">Precisão ao Longo do Tempo</h3>
          <div className="h-56">
            <AccuracyChart predictions={predictions} />
          </div>
        </div>
        
        <div className="bg-surface rounded-xl p-4 shadow-md">
          <h3 className="text-sm font-medium text-text-secondary mb-2">Acertos vs Erros</h3>
          <div className="h-56">
            <HitsVsMissesChart predictions={predictions} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
