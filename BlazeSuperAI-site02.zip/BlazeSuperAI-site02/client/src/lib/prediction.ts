import { Round, Prediction, ColorType, ConfidenceLevel } from "../types";
import { generateId, getConfidenceLevel } from "./utils";

// Function to predict the next color based on historical data
export const predictNextColor = (rounds: Round[]): { color: ColorType; confidence: number } => {
  // If we don't have any rounds, make a basic prediction
  if (rounds.length === 0) {
    const colors: ColorType[] = ['red', 'black', 'white'];
    const weights = [7, 7, 1]; // Approximate odds
    return {
      color: weightedRandom(colors, weights),
      confidence: 0.3 // Low confidence with no data
    };
  }

  // Count recent occurrences (consider the last 10 rounds or fewer if not available)
  const recentRounds = rounds.slice(0, Math.min(10, rounds.length));
  let redCount = 0, blackCount = 0, whiteCount = 0;
  
  recentRounds.forEach(round => {
    if (round.color === 'red') redCount++;
    else if (round.color === 'black') blackCount++;
    else whiteCount++;
  });
  
  // Simple pattern detection
  let prediction: ColorType, confidence: number;
  
  if (rounds.length < 3) {
    // Not enough data for pattern detection, use basic frequency
    const colors: ColorType[] = ['red', 'black', 'white'];
    const weights = [7, 7, 1]; // Approximate odds
    prediction = weightedRandom(colors, weights);
    confidence = 0.3; // Low confidence with little data
  } else {
    // Look for patterns in the last 5 rounds
    const last5 = rounds.slice(0, Math.min(5, rounds.length)).map(r => r.color);
    
    // Check for alternating pattern
    const isAlternating = last5.length >= 3 && 
      last5[0] !== last5[1] && 
      last5[1] !== last5[2] && 
      (last5.length < 4 || last5[2] !== last5[3]);
    
    // Check for streak
    const streakColor = last5[0];
    const hasStreak = last5.length >= 3 && 
      last5.slice(0, 3).every(c => c === streakColor);
    
    if (isAlternating) {
      // Predict alternating pattern continues
      prediction = last5[0] === 'red' ? 'black' : 
                  last5[0] === 'black' ? 'red' : 
                  last5[1] === 'red' ? 'black' : 'red';
      confidence = 0.7;
    } else if (hasStreak && streakColor !== 'white') {
      // After a streak, predict a change is likely
      prediction = streakColor === 'red' ? 'black' : 'red';
      confidence = 0.65;
    } else if (whiteCount > 0 && rounds.length < 15) {
      // White appeared recently in a small sample, less likely soon
      prediction = redCount > blackCount ? 'black' : 'red';
      confidence = 0.6;
    } else {
      // Fall back to frequency-based prediction
      const total = redCount + blackCount + whiteCount || 1;
      
      // Check if white is due (very rare)
      const whiteIsDue = rounds.length > 15 && whiteCount === 0;
      
      if (whiteIsDue && Math.random() < 0.1) {
        prediction = 'white';
        confidence = 0.25;
      } else if (redCount / total > 0.6) {
        prediction = 'black'; // Red overrepresented, expect regression to mean
        confidence = 0.6 + (redCount / total - 0.5);
      } else if (blackCount / total > 0.6) {
        prediction = 'red'; // Black overrepresented, expect regression to mean
        confidence = 0.6 + (blackCount / total - 0.5);
      } else {
        // Fairly even distribution, slight edge to less frequent
        prediction = redCount <= blackCount ? 'red' : 'black';
        confidence = 0.55;
      }
    }
  }
  
  // Add some randomness to confidence
  confidence = Math.min(0.95, Math.max(0.2, confidence + (Math.random() * 0.1 - 0.05)));
  
  return { color: prediction, confidence };
};

// Generate a message based on prediction
export const generateAIMessage = (color: ColorType, confidenceLevel: ConfidenceLevel): string => {
  if (color === 'red') {
    if (confidenceLevel === 'high') {
      return 'Alta chance de vermelho na próxima rodada!';
    } else if (confidenceLevel === 'medium') {
      return 'Chance média de vermelho na próxima rodada.';
    } else {
      return 'Possibilidade baixa de vermelho, considere aguardar.';
    }
  } else if (color === 'black') {
    if (confidenceLevel === 'high') {
      return 'Alta chance de preto na próxima rodada!';
    } else if (confidenceLevel === 'medium') {
      return 'Chance média de preto na próxima rodada.';
    } else {
      return 'Possibilidade baixa de preto, considere aguardar.';
    }
  } else {
    if (confidenceLevel === 'high' || confidenceLevel === 'medium') {
      return 'Atenção! Possibilidade de branco detectada!';
    } else {
      return 'Talvez seja a hora do branco... Mas o risco é alto.';
    }
  }
};

// Create a new prediction object
export const createPrediction = (color: ColorType, confidence: number): Prediction => {
  return {
    id: generateId(),
    color,
    confidence,
    timestamp: Date.now()
  };
};

// Update prediction with actual result
export const updatePredictionWithResult = (
  prediction: Prediction, 
  actualColor: ColorType
): Prediction => {
  return {
    ...prediction,
    actual: actualColor,
    correct: prediction.color === actualColor
  };
};

// Utility for weighted random selection
export const weightedRandom = (items: ColorType[], weights: number[]): ColorType => {
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  let random = Math.random() * totalWeight;
  
  for (let i = 0; i < items.length; i++) {
    if (random < weights[i]) {
      return items[i];
    }
    random -= weights[i];
  }
  
  return items[0]; // Fallback
};
