import { useEffect, useRef } from "react";
import { Prediction } from "../../types";
import { Chart, LineController, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Filler } from "chart.js";

// Register required Chart.js components
Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Filler);

interface AccuracyChartProps {
  predictions: Prediction[];
}

const AccuracyChart = ({ predictions }: AccuracyChartProps) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    // Prepare data for chart
    const labels: string[] = [];
    const accuracyData: number[] = [];
    
    // Use real data if available, otherwise use mock data
    if (predictions.length > 5) {
      // Group predictions in chunks of 5 (or whatever makes sense)
      const numChunks = Math.min(10, Math.floor(predictions.length / 5));
      
      for (let i = 0; i < numChunks; i++) {
        const startIdx = i * 5;
        const chunk = predictions.slice(startIdx, startIdx + 5).filter(p => p.correct !== undefined);
        const correct = chunk.filter(p => p.correct === true).length;
        const total = chunk.length;
        
        if (total > 0) {
          labels.push(`${startIdx+1}-${startIdx+5}`);
          accuracyData.push((correct / total) * 100);
        }
      }
    } else {
      // Not enough data yet, show empty chart with proper labels
      labels.push('Aguardando dados');
      accuracyData.push(0);
    }
    
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Create the chart
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Precisão (%)',
          data: accuracyData,
          borderColor: '#6200EA',
          backgroundColor: 'rgba(98, 0, 234, 0.2)',
          borderWidth: 2,
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
              color: '#BBBBBB',
              font: {
                family: 'Roboto'
              }
            }
          },
          x: {
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
              color: '#BBBBBB',
              font: {
                family: 'Roboto'
              }
            }
          }
        },
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `Precisão: ${context.raw}%`;
              }
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [predictions]);
  
  return <canvas ref={chartRef} />;
};

export default AccuracyChart;
