import { useEffect, useRef } from "react";
import { Prediction } from "../../types";
import { Chart, BarController, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from "chart.js";

// Register required Chart.js components
Chart.register(BarController, BarElement, CategoryScale, LinearScale, Tooltip, Legend);

interface HitsVsMissesChartProps {
  predictions: Prediction[];
}

const HitsVsMissesChart = ({ predictions }: HitsVsMissesChartProps) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    // Calculate hits and misses
    const resolvedPredictions = predictions.filter(p => p.correct !== undefined);
    const hits = resolvedPredictions.filter(p => p.correct === true).length;
    const misses = resolvedPredictions.length - hits;
    
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Create the chart
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Acertos', 'Erros'],
        datasets: [{
          data: [hits, misses],
          backgroundColor: ['#4CAF50', '#F44336'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const value = context.raw as number;
                const total = hits + misses;
                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                return `${value} (${percentage}%)`;
              }
            }
          }
        },
        scales: {
          x: {
            beginAtZero: true,
            grid: {
              color: 'rgba(255, 255, 255, 0.1)'
            },
            ticks: {
              color: '#BBBBBB',
              font: {
                family: 'Roboto'
              }
            }
          },
          y: {
            grid: {
              display: false
            },
            ticks: {
              color: '#BBBBBB',
              font: {
                family: 'Roboto'
              }
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [predictions]);
  
  return <canvas ref={chartRef} />;
};

export default HitsVsMissesChart;
