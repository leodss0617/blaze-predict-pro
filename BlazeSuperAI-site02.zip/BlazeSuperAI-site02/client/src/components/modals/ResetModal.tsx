import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../ui/dialog";
import { Button } from "../ui/button";

interface ResetModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const ResetModal = ({ open, onClose, onConfirm }: ResetModalProps) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-surface border-gray-700 p-6 m-4 max-w-md rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold mb-3">Resetar Histórico?</DialogTitle>
        </DialogHeader>
        
        <p className="text-text-secondary mb-4">
          Isso apagará todos os dados e a IA perderá todo o aprendizado acumulado.
        </p>
        
        <DialogFooter className="flex flex-row gap-3 sm:gap-3">
          <Button 
            className="flex-1 py-3 bg-dark text-text-primary rounded-lg font-medium"
            onClick={onClose}
          >
            Cancelar
          </Button>
          <Button 
            className="flex-1 py-3 bg-destructive text-white rounded-lg font-medium"
            onClick={onConfirm}
          >
            Sim, Resetar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ResetModal;
