import { useState } from "react";
import { AppState, Round, Prediction, ColorType } from "../types";
import InputSection from "./InputSection";
import PredictionSection from "./PredictionSection";
import StatsSection from "./StatsSection";
import HistorySection from "./HistorySection";
import HelpModal from "./modals/HelpModal";
import ResetModal from "./modals/ResetModal";
import { Button } from "./ui/button";
import { resetAppState } from "../lib/storage";
import { getConfidenceLevel } from "../lib/utils";
import { 
  predictNextColor, 
  createPrediction, 
  updatePredictionWithResult,
  generateAIMessage 
} from "../lib/prediction";
import { generateId, getColorFromNumber } from "../lib/utils";
import { useToast } from "../hooks/use-toast";
import { HelpCircle } from "lucide-react";

interface MainAppProps {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
}

const MainApp = ({ state, setState }: MainAppProps) => {
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const { toast } = useToast();

  const handleAddRound = (number: number) => {
    const color = getColorFromNumber(number);
    
    if (color === null) {
      toast({
        title: "Número inválido",
        description: "Digite um número entre 0 e 14.",
        variant: "destructive"
      });
      return;
    }
    
    // Create new round
    const newRound: Round = {
      id: generateId(),
      number,
      color,
      timestamp: Date.now()
    };
    
    // Check if prediction was correct for previous round
    const lastPrediction = state.predictions[0];
    let updatedPredictions = [...state.predictions];
    
    if (lastPrediction && lastPrediction.actual === undefined) {
      updatedPredictions[0] = updatePredictionWithResult(lastPrediction, color);
    }
    
    // Make new prediction for next round
    const newRounds = [newRound, ...state.rounds];
    const { color: predictedColor, confidence } = predictNextColor(newRounds);
    const confidenceLevel = getConfidenceLevel(confidence);
    const message = generateAIMessage(predictedColor, confidenceLevel);
    
    const newPrediction = createPrediction(predictedColor, confidence);
    updatedPredictions = [newPrediction, ...updatedPredictions];
    
    // Update state
    setState({
      ...state,
      rounds: newRounds,
      predictions: updatedPredictions,
      currentPrediction: {
        color: predictedColor,
        confidence,
        confidenceLevel,
        message
      }
    });
    
    toast({
      title: "Rodada adicionada",
      description: `Número ${number} (${color.charAt(0).toUpperCase() + color.slice(1)}) adicionado com sucesso.`
    });
  };
  
  const handleRemoveLastRound = () => {
    if (state.rounds.length === 0) {
      toast({
        title: "Nenhuma rodada para remover",
        description: "O histórico já está vazio.",
        variant: "destructive"
      });
      return;
    }
    
    // Remove last round and prediction
    const newRounds = [...state.rounds.slice(1)];
    const newPredictions = [...state.predictions.slice(1)];
    
    // Update the current prediction (if any rounds left)
    let currentPrediction = null;
    
    if (newRounds.length > 0 && newPredictions.length > 0) {
      const lastPrediction = newPredictions[0];
      
      // Reset the "actual" and "correct" fields
      if (lastPrediction) {
        newPredictions[0] = {
          ...lastPrediction,
          actual: undefined,
          correct: undefined
        };
        
        const confidenceLevel = getConfidenceLevel(lastPrediction.confidence);
        currentPrediction = {
          color: lastPrediction.color,
          confidence: lastPrediction.confidence,
          confidenceLevel,
          message: generateAIMessage(lastPrediction.color, confidenceLevel)
        };
      }
    }
    
    // Update state
    setState({
      ...state,
      rounds: newRounds,
      predictions: newPredictions,
      currentPrediction
    });
    
    toast({
      title: "Rodada removida",
      description: "Última rodada removida com sucesso."
    });
  };
  
  const handleResetApp = () => {
    // Show confirmation modal
    setShowResetModal(true);
  };
  
  const confirmReset = () => {
    // Reset everything
    setState(resetAppState());
    setShowResetModal(false);
    
    toast({
      title: "Histórico resetado",
      description: "Todos os dados foram apagados com sucesso."
    });
  };
  
  // Initialize prediction on first load if needed
  if (state.rounds.length > 0 && !state.currentPrediction) {
    const { color, confidence } = predictNextColor(state.rounds);
    const confidenceLevel = getConfidenceLevel(confidence);
    
    state.currentPrediction = {
      color,
      confidence,
      confidenceLevel,
      message: generateAIMessage(color, confidenceLevel)
    };
  }

  return (
    <div className="flex flex-col min-h-screen pb-24 relative">
      {/* Header */}
      <header className="bg-dark py-4 px-4 shadow-md sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-montserrat font-bold">
            Blaze Supreme <span className="text-primary">AI</span>
          </h1>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full bg-surface"
            onClick={() => setShowHelpModal(true)}
          >
            <HelpCircle size={24} />
          </Button>
        </div>
      </header>

      {/* Input Section */}
      <InputSection onAddRound={handleAddRound} />

      {/* Prediction Section */}
      <PredictionSection 
        prediction={state.currentPrediction || {
          color: 'black',
          confidence: 0.5,
          confidenceLevel: 'medium',
          message: 'Adicione rodadas para obter previsões precisas.'
        }} 
      />

      {/* Stats Section */}
      <StatsSection rounds={state.rounds} predictions={state.predictions} />

      {/* History Section */}
      <HistorySection rounds={state.rounds} predictions={state.predictions} />

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-dark border-t border-gray-800 p-4 flex gap-3 z-10">
        <Button 
          className="flex-1 py-3 bg-surface text-foreground rounded-lg font-medium"
          onClick={handleRemoveLastRound}
        >
          Remover Última
        </Button>
        <Button 
          className="flex-1 py-3 bg-destructive text-destructive-foreground rounded-lg font-medium"
          onClick={handleResetApp}
        >
          Resetar Histórico
        </Button>
      </div>

      {/* Modals */}
      <HelpModal open={showHelpModal} onClose={() => setShowHelpModal(false)} />
      <ResetModal 
        open={showResetModal} 
        onClose={() => setShowResetModal(false)} 
        onConfirm={confirmReset} 
      />
    </div>
  );
};

export default MainApp;
