import { useState, useEffect } from "react";
import WelcomeScreen from "./components/WelcomeScreen";
import MainApp from "./components/MainApp";
import { AppState } from "./types";
import { loadAppState, saveAppState } from "./lib/storage";
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";

function App() {
  const [state, setState] = useState<AppState>(() => loadAppState());
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      saveAppState(state);
    }
  }, [state, isLoading]);

  const startApp = () => {
    setState(prev => ({ ...prev, hasVisited: true }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-2xl font-bold text-primary">Carregando...</div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen">
        {!state.hasVisited ? (
          <WelcomeScreen onStart={startApp} />
        ) : (
          <MainApp state={state} setState={setState} />
        )}
      </div>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
