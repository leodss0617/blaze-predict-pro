import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Round, Prediction, ConfidenceLevel, ColorType } from "../types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getColorFromNumber(num: number): ColorType | null {
  if (isNaN(num) || num < 0 || num > 14) return null;
  if (num === 0) return 'white';
  if (num >= 1 && num <= 7) return 'red';
  return 'black';
}

export function getColorDisplayClass(color: ColorType | null): string {
  if (color === 'red') return 'bg-blaze-red';
  if (color === 'black') return 'bg-blaze-black';
  if (color === 'white') return 'bg-blaze-white';
  return 'bg-gray-700';
}

export function getColorTextClass(color: ColorType): string {
  if (color === 'white') return 'text-dark';
  return 'text-white';
}

export function getColorName(color: ColorType): string {
  if (color === 'red') return 'Vermelho';
  if (color === 'black') return 'Preto';
  return 'Branco';
}

export function getConfidenceLevel(confidence: number): ConfidenceLevel {
  if (confidence >= 0.7) return 'high';
  if (confidence >= 0.5) return 'medium';
  return 'low';
}

export function getConfidenceText(level: ConfidenceLevel): string {
  if (level === 'high') return 'ALTA';
  if (level === 'medium') return 'MÉDIA';
  return 'BAIXA';
}

export function getConfidenceBarClass(level: ConfidenceLevel): string {
  if (level === 'high') return 'bg-green-500';
  if (level === 'medium') return 'bg-yellow-500';
  return 'bg-red-500';
}

export function getConfidenceContainerClass(level: ConfidenceLevel): string {
  if (level === 'high') return 'confidence-high';
  if (level === 'medium') return 'confidence-medium';
  return 'confidence-low';
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

export function calculateAccuracyTrend(predictions: Prediction[]): number {
  if (predictions.length < 10) return 0;
  
  const recentPredictions = predictions.slice(0, 5).filter(p => p.correct !== undefined);
  const olderPredictions = predictions.slice(5, 10).filter(p => p.correct !== undefined);
  
  if (recentPredictions.length === 0 || olderPredictions.length === 0) return 0;
  
  const recentAccuracy = recentPredictions.filter(p => p.correct).length / recentPredictions.length;
  const olderAccuracy = olderPredictions.filter(p => p.correct).length / olderPredictions.length;
  
  return Math.round((recentAccuracy - olderAccuracy) * 100);
}

export function formatTimestamp(timestamp: number): string {
  const date = new Date(timestamp);
  return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
}
