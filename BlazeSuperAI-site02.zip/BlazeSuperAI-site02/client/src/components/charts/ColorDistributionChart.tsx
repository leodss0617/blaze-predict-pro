import { useEffect, useRef } from "react";
import { Round } from "../../types";
import { Chart, PieController, ArcElement, Tooltip, Legend } from "chart.js";

// Register required Chart.js components
Chart.register(PieController, ArcElement, Tooltip, Legend);

interface ColorDistributionChartProps {
  rounds: Round[];
}

const ColorDistributionChart = ({ rounds }: ColorDistributionChartProps) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);
  
  useEffect(() => {
    if (!chartRef.current) return;
    
    // Count color occurrences
    let redCount = 0, blackCount = 0, whiteCount = 0;
    
    rounds.forEach(round => {
      if (round.color === 'red') redCount++;
      else if (round.color === 'black') blackCount++;
      else whiteCount++;
    });
    
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    // Create the chart
    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;
    
    chartInstance.current = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ['Vermelho', 'Preto', 'Branco'],
        datasets: [{
          data: [redCount, blackCount, whiteCount],
          backgroundColor: ['#F44336', '#212121', '#FFFFFF'],
          borderColor: ['#D32F2F', '#000000', '#E0E0E0'],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: {
              color: '#BBBBBB',
              font: {
                family: 'Roboto'
              }
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const label = context.label || '';
                const value = context.raw as number;
                const total = redCount + blackCount + whiteCount;
                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                return `${label}: ${value} (${percentage}%)`;
              }
            }
          }
        }
      }
    });
    
    // Cleanup function
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [rounds]);
  
  return <canvas ref={chartRef} />;
};

export default ColorDistributionChart;
