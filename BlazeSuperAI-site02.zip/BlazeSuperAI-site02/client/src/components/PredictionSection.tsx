import { 
  getColorDisplayClass, 
  getConfidenceBarClass, 
  getConfidenceContainerClass,
  getConfidenceText
} from "../lib/utils";
import { ColorType, ConfidenceLevel } from "../types";

interface PredictionSectionProps {
  prediction: {
    color: ColorType;
    confidence: number;
    confidenceLevel: ConfidenceLevel;
    message: string;
  };
}

const PredictionSection = ({ prediction }: PredictionSectionProps) => {
  const { color, confidence, confidenceLevel, message } = prediction;
  
  const colorClass = getColorDisplayClass(color);
  const confidenceBarClass = getConfidenceBarClass(confidenceLevel);
  const confidenceContainerClass = getConfidenceContainerClass(confidenceLevel);
  const confidencePercent = Math.round(confidence * 100);
  const confidenceText = getConfidenceText(confidenceLevel);
  
  return (
    <section className="px-4 mb-6">
      <div className={`bg-surface rounded-xl p-4 shadow-md ${confidenceContainerClass} transition-all duration-300`}>
        <h2 className="text-xl font-montserrat font-bold mb-2">Previsão da IA</h2>
        
        <div className="flex items-center gap-4 mb-4">
          <div className={`h-16 w-16 ${colorClass} rounded-xl flex items-center justify-center text-3xl font-bold`}></div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-text-secondary">Confiança:</span>
              <span 
                className={`font-medium px-2 py-1 rounded-full text-white text-xs ${confidenceBarClass}`}
              >
                {confidenceText}
              </span>
            </div>
            <div className="w-full bg-dark rounded-full h-2">
              <div className={`${confidenceBarClass} h-2 rounded-full transition-all duration-300`} style={{ width: `${confidencePercent}%` }}></div>
            </div>
          </div>
        </div>
        
        <p className="text-lg font-medium border-t border-gray-700 pt-3">
          {message}
        </p>
      </div>
    </section>
  );
};

export default PredictionSection;
